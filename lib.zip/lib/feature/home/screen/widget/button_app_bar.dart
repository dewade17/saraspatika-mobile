import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:saraspatika/feature/login/data/provider/auth_provider.dart';

class ButtonAppBar extends StatefulWidget {
  const ButtonAppBar({super.key});

  @override
  State<ButtonAppBar> createState() => _ButtonAppBarState();
}

class _ButtonAppBarState extends State<ButtonAppBar> {
  final bool _isProfileComplete = true;
  final bool isKerja = permissionType == 'kerja';

  final IconData menuIcon = isKerja
      ? Icons.business_center
      : Icons.assignment_add;
  final String menuTitle = isKerja ? 'Agenda\nKerja' : 'Agenda\nMengajar';
  final String routeName = isKerja ? '/screen-agenda-kerja' : '/screen-agenda';
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Card(
          child: _isProfileComplete
              ? Column(
                  children: [
                    const SizedBox(height: 10),
                    Padding(
                      padding: const EdgeInsets.all(4),
                      child: Row(
                        children: [
                          Expanded(
                            child: InkWell(
                              onTap: () {
                                // UI-only: placeholder route
                                Navigator.pushNamed(
                                  context,
                                  '/absensi-kedatangan',
                                );
                              },
                              child: const Center(
                                child: Column(
                                  children: [
                                    Icon(
                                      Icons.calendar_month,
                                      size: 30,
                                      color: Color(0xFF92E3A9),
                                    ),
                                    Text(
                                      'Absensi Kedatangan',
                                      textAlign: TextAlign.center,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: InkWell(
                              onTap: () {
                                // UI-only: placeholder route
                                Navigator.pushNamed(
                                  context,
                                  '/absensi-kepulangan',
                                );
                              },
                              child: const Center(
                                child: Column(
                                  children: [
                                    Icon(
                                      Icons.calendar_month,
                                      size: 30,
                                      color: Colors.red,
                                    ),
                                    Text(
                                      'Absensi Kepulangan',
                                      textAlign: TextAlign.center,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: InkWell(
                              onTap: () {
                                // Navigasi sesuai rute yang ditentukan di atas
                                Navigator.pushNamed(context, routeName);
                              },
                              child: Center(
                                child: Column(
                                  mainAxisSize: MainAxisSize
                                      .min, // Menjaga column tetap di tengah
                                  children: [
                                    Icon(
                                      menuIcon,
                                      size: 30,
                                      color: Colors.blueAccent,
                                    ),
                                    const SizedBox(
                                      height: 4,
                                    ), // Memberi sedikit jarak antara icon dan teks
                                    Text(
                                      menuTitle,
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: InkWell(
                              onTap: () async {
                                final authProvider = Provider.of<AuthProvider>(
                                  context,
                                  listen: false,
                                );

                                await authProvider.logout();
                                if (!mounted) return;

                                Navigator.of(context).pushNamedAndRemoveUntil(
                                  '/login',
                                  (route) => false,
                                );
                              },
                              child: const Center(
                                child: Column(
                                  children: [
                                    Icon(
                                      Icons.power_settings_new_sharp,
                                      size: 30,
                                    ),
                                    Text('Logout'),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                  ],
                )
              : const SizedBox(),
        ),
      ],
    );
  }
}
