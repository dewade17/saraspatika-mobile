import 'package:flutter/material.dart';

class ButtonAppBar extends StatefulWidget {
  const ButtonAppBar({super.key});

  @override
  State<ButtonAppBar> createState() => _ButtonAppBarState();
}

class _ButtonAppBarState extends State<ButtonAppBar> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
