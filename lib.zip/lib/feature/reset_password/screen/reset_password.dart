import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import 'package:saraspatika/feature/reset_password/data/provider/reset_password_provider.dart';

class ResetPassword extends StatefulWidget {
  const ResetPassword({super.key});

  @override
  State<ResetPassword> createState() => _ResetPasswordState();
}

class _ResetPasswordState extends State<ResetPassword> {
  final _emailFormKey = GlobalKey<FormState>();
  final _resetFormKey = GlobalKey<FormState>();

  final _emailC = TextEditingController();
  final _tokenC = TextEditingController();
  final _newPasswordC = TextEditingController();

  bool _obscureNewPassword = true;
  bool _tokenRequested = false;

  @override
  void dispose() {
    _emailC.dispose();
    _tokenC.dispose();
    _newPasswordC.dispose();
    super.dispose();
  }

  String? _validateEmail(String? v) {
    final s = (v ?? '').trim();
    if (s.isEmpty) return 'Email wajib diisi';
    if (!s.contains('@')) return 'Format email tidak valid';
    return null;
  }

  String? _validateToken(String? v) {
    final s = (v ?? '').trim();
    if (s.isEmpty) return 'Token wajib diisi';
    return null;
  }

  String? _validateNewPassword(String? v) {
    final s = (v ?? '');
    if (s.isEmpty) return 'Password baru wajib diisi';
    if (s.length < 6) return 'Minimal 6 karakter';
    return null;
  }

  Future<void> _onRequestToken() async {
    final p = context.read<ResetPasswordProvider>();
    FocusScope.of(context).unfocus();

    if (!(_emailFormKey.currentState?.validate() ?? false)) return;

    try {
      await p.requestResetToken(email: _emailC.text.trim());
      if (!mounted) return;

      setState(() => _tokenRequested = true);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Jika email terdaftar, token reset sudah dikirim.'),
        ),
      );
    } catch (_) {
      if (!mounted) return;
      final msg =
          context.read<ResetPasswordProvider>().errorMessage ??
          'Gagal kirim token.';
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
    }
  }

  Future<void> _onResetPassword() async {
    final p = context.read<ResetPasswordProvider>();
    FocusScope.of(context).unfocus();

    if (!(_emailFormKey.currentState?.validate() ?? false)) return;
    if (!(_resetFormKey.currentState?.validate() ?? false)) return;

    try {
      final ok = await p.resetPassword(
        email: _emailC.text.trim(),
        code: _tokenC.text.trim(),
        newPassword: _newPasswordC.text,
      );

      if (!mounted) return;

      if (ok) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Password berhasil direset. Silakan login.'),
          ),
        );
        Navigator.of(context).pushReplacementNamed('/login');
      } else {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('Reset password gagal.')));
      }
    } catch (_) {
      if (!mounted) return;
      final msg =
          context.read<ResetPasswordProvider>().errorMessage ??
          'Reset password gagal.';
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.watch<ResetPasswordProvider>();

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Image.asset(
                'lib/assets/images/Reset_password.png',
                height: 250,
                width: 250,
              ),
              const SizedBox(height: 20),
              Text(
                "Reset Password",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey.shade800,
                ),
              ),
              const SizedBox(height: 20),

              // ===== FORM EMAIL =====
              Form(
                key: _emailFormKey,
                child: Column(
                  children: [
                    Center(
                      child: SizedBox(
                        width: 350,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Email',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.grey.shade600,
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 0,
                              ),
                              margin: const EdgeInsets.symmetric(vertical: 8),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: Colors.grey.shade400),
                              ),
                              child: TextFormField(
                                controller: _emailC,
                                validator: _validateEmail,
                                onChanged: (_) {
                                  if (p.errorMessage != null) {
                                    context
                                        .read<ResetPasswordProvider>()
                                        .clearError();
                                  }
                                },
                                decoration: const InputDecoration(
                                  hintText: "masukan email",
                                  floatingLabelBehavior:
                                      FloatingLabelBehavior.always,
                                  hintStyle: TextStyle(
                                    color: Colors.grey,
                                    fontStyle: FontStyle.italic,
                                  ),
                                  icon: Icon(Icons.alternate_email_rounded),
                                  border: InputBorder.none,
                                ),
                                keyboardType: TextInputType.emailAddress,
                                textInputAction: TextInputAction.done,
                              ),
                            ),
                            Row(
                              children: [
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFF92E3A9),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                  ),
                                  onPressed: p.isLoading
                                      ? null
                                      : _onRequestToken,
                                  child: p.isLoading
                                      ? const SizedBox(
                                          width: 18,
                                          height: 18,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                          ),
                                        )
                                      : const Text('Kirim Kode'),
                                ),
                                const SizedBox(width: 12),
                                if (_tokenRequested)
                                  const Text(
                                    'Token dikirim (cek email)',
                                    style: TextStyle(fontSize: 12),
                                  ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 10),

              // ===== FORM TOKEN + PASSWORD BARU =====
              Form(
                key: _resetFormKey,
                child: Column(
                  children: [
                    Center(
                      child: SizedBox(
                        width: 350,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Token",
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.grey.shade600,
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                              ),
                              margin: const EdgeInsets.symmetric(vertical: 8),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: Colors.grey.shade400),
                              ),
                              child: TextFormField(
                                controller: _tokenC,
                                validator: _validateToken,
                                decoration: const InputDecoration(
                                  hintText: "Token",
                                  floatingLabelBehavior:
                                      FloatingLabelBehavior.always,
                                  hintStyle: TextStyle(
                                    color: Colors.grey,
                                    fontStyle: FontStyle.italic,
                                  ),
                                  icon: Icon(Icons.generating_tokens_outlined),
                                  border: InputBorder.none,
                                ),
                                textInputAction: TextInputAction.next,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Center(
                      child: SizedBox(
                        width: 350,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Password Baru",
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.grey.shade600,
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                              ),
                              margin: const EdgeInsets.symmetric(vertical: 8),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: Colors.grey.shade400),
                              ),
                              child: TextFormField(
                                controller: _newPasswordC,
                                validator: _validateNewPassword,
                                obscureText: _obscureNewPassword,
                                decoration: InputDecoration(
                                  hintText: "Password Baru",
                                  floatingLabelBehavior:
                                      FloatingLabelBehavior.always,
                                  hintStyle: const TextStyle(
                                    color: Colors.grey,
                                    fontStyle: FontStyle.italic,
                                  ),
                                  icon: const Icon(Icons.lock),
                                  border: InputBorder.none,
                                  suffixIcon: IconButton(
                                    icon: Icon(
                                      _obscureNewPassword
                                          ? Icons.visibility_off
                                          : Icons.visibility,
                                    ),
                                    onPressed: () {
                                      setState(() {
                                        _obscureNewPassword =
                                            !_obscureNewPassword;
                                      });
                                    },
                                  ),
                                ),
                                textInputAction: TextInputAction.done,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF92E3A9),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: p.isLoading ? null : _onResetPassword,
                      child: p.isLoading
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Text("Reset Password"),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),
              GestureDetector(
                onTap: p.isLoading
                    ? null
                    : () {
                        Navigator.of(context).pushReplacementNamed('/login');
                      },
                child: Text(
                  'Login',
                  style: GoogleFonts.inter(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
