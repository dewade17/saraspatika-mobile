import 'package:flutter/material.dart';
import 'package:saraspatika/core/constants/colors.dart';

class PengajuanScreen extends StatefulWidget {
  const PengajuanScreen({super.key});

  @override
  State<PengajuanScreen> createState() => _PengajuanScreenState();
}

class _PengajuanScreenState extends State<PengajuanScreen> {
  static const List<String> _jenisIzinList = ['izin', 'cuti', 'sakit'];
  String? _selectedJenisIzin;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: AppColors.primaryColor),
      body: Stack(
        children: [
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 200,
              color: AppColors.primaryColor,
              child: const Padding(
                padding: EdgeInsets.only(top: 30, left: 70, right: 70),
                child: Text(
                  "Form Permohonan Cuti/Izin/Sakit",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
          SafeArea(
            child: GestureDetector(
              onTap: () => FocusScope.of(context).unfocus(),
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16.0,
                  vertical: 24.0,
                ),
                child: Column(
                  children: [
                    const SizedBox(height: 90),
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          const SizedBox(height: 24),

                          // Dropdown jenis izin (UI-only, state untuk selected value)
                          DropdownButtonFormField<String>(
                            value: _selectedJenisIzin,
                            decoration: InputDecoration(
                              labelText: 'Jenis Izin',
                              prefixIcon: const Icon(Icons.list_alt),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            items: _jenisIzinList
                                .map(
                                  (j) => DropdownMenuItem(
                                    value: j,
                                    child: Text(j),
                                  ),
                                )
                                .toList(),
                            onChanged: (val) {
                              setState(() => _selectedJenisIzin = val);
                            },
                          ),
                          const SizedBox(height: 20),

                          // Tanggal mulai (UI-only, non-aktif)
                          TextFormField(
                            readOnly: true,
                            enabled: false,
                            decoration: InputDecoration(
                              labelText: 'Mulai (YYYY-MM-DD)',
                              prefixIcon: const Icon(Icons.date_range),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),

                          // Tanggal selesai (UI-only, non-aktif)
                          TextFormField(
                            readOnly: true,
                            enabled: false,
                            decoration: InputDecoration(
                              labelText: 'Selesai (YYYY-MM-DD)',
                              prefixIcon: const Icon(Icons.date_range_outlined),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),

                          // Alasan (UI-only, non-aktif)
                          TextFormField(
                            maxLines: 3,
                            enabled: false,
                            decoration: InputDecoration(
                              labelText: 'Alasan',
                              alignLabelWithHint: true,
                              prefixIcon: const Padding(
                                padding: EdgeInsets.only(top: 12),
                                child: Icon(Icons.comment),
                              ),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                          const SizedBox(height: 24),

                          // Preview file placeholder (UI-only)
                          Container(
                            height: 120,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: Colors.black12),
                            ),
                            child: const Center(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.insert_drive_file_outlined),
                                  SizedBox(height: 8),
                                  Text('Belum ada file diunggah'),
                                ],
                              ),
                            ),
                          ),

                          const SizedBox(height: 32),

                          // Tombol unggah (UI-only, non-aktif)
                          OutlinedButton.icon(
                            onPressed: null,
                            icon: const Icon(Icons.camera_alt_outlined),
                            label: const Text('Unggah Bukti'),
                            style: OutlinedButton.styleFrom(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              side: BorderSide(color: AppColors.primaryColor),
                              padding: const EdgeInsets.symmetric(vertical: 14),
                            ),
                          ),

                          const SizedBox(height: 32),

                          // Tombol submit (UI-only, non-aktif)
                          ElevatedButton(
                            onPressed: null,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.primaryColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: const Padding(
                              padding: EdgeInsets.symmetric(vertical: 16),
                              child: Text(
                                'Kirim Permintaan',
                                style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
