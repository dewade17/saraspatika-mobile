enum BuktiKind { none, image, pdf }

class LeaveRequestUiModel {
  final String leaveId;
  final String jenisIzin;
  final String alasan;
  final DateTime tanggalMulai;
  final DateTime tanggalSelesai;
  final String? status;
  final BuktiKind bukti;

  const LeaveRequestUiModel({
    required this.leaveId,
    required this.jenisIzin,
    required this.alasan,
    required this.tanggalMulai,
    required this.tanggalSelesai,
    required this.status,
    required this.bukti,
  });
}
